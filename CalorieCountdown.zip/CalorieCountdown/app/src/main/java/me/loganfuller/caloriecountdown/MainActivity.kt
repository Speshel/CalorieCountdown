package me.loganfuller.caloriecountdown

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var txtCaloriesCounter: TextView
    lateinit var totalProgress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtCaloriesCounter = findViewById(R.id.txtCaloriesCounter)
        totalProgress = findViewById(R.id.totalProgress)

        init()
    }

    fun init() {
        val sharedPrefs = this.getSharedPreferences(getString(R.string.user_data_preferences), Context.MODE_PRIVATE)
        val defaultValue = 0

        val totalCalories = sharedPrefs.getInt(getString(R.string.calories_total), defaultValue)
        val caloriesToBurn = sharedPrefs.getInt(getString(R.string.calories_left_key), defaultValue)

        /* Set progress bar progress calculated as percentage returned from '(caloriesToBurn / totalCalories) * 100' */
        val percentProgress = (caloriesToBurn / totalCalories) * 100
        totalProgress.progress = percentProgress
    }
}
